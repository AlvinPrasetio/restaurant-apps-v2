import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';
import '../styles/responsive.css';
import data from '../public/data/DATA.json';

const listRestaurant = (data) => {
  data.restaurants.forEach(restaurant => {
      const restaurantItem = document.querySelector('.posts');
      restaurantItem.innerHTML += `
        <article tabindex="0" class="post-card">
          <div class="post-card_content">
          <p tabindex="0" class="post-card_city">Location: ${restaurant.city}</p>
          </div>

          <img
            tabindex="0"
            class="post-card_header"
            src="${restaurant.pictureId}" alt="${restaurant.name}"
          />
          
          <div class="post-card_content">
            <p tabindex="0" class="post-card_rating">Rating: ${restaurant.rating}</p>
            <h1 tabindex="0" class="post-card_title">${restaurant.name}</h1>
            <p tabindex="0" class="post-card_description">${restaurant.description}</p>
          </div>
        </article>
      `;
  })
}
listRestaurant(data);


const menu = document.querySelector("#menu");
const hero = document.querySelector(".hero");
const main = document.querySelector("main");
const drawer = document.querySelector("#drawer");

menu.addEventListener("click", (event) => {
  drawer.classList.toggle("open");
  event.preventDefault();
});

hero.addEventListener("click", () => {
  drawer.classList.remove("open");
});

main.addEventListener("click", () => {
  drawer.classList.remove("open");
});